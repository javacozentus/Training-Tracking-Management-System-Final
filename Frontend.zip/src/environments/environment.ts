export const environment = {
  production: false,
  title: 'Local Environment Heading',
  apiURL: 'http://localhost:2023',
  loginURL:'http://localhost:8080'
};